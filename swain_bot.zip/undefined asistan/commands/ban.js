let { Client, Message, MessageEmbed, Permissions } = require("discord.js");
let moment = require("moment");
moment.locale("tr");

module.exports = {
    name: "ban-user",
    aliases: [
        "ban",
        "kick",
        "banuser",
        "banla"
    ],
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String || Map || Number} params 
     */
    load: async function(client, message, params){
        if(!message.member.permissions.has(Permissions.FLAGS.BAN_MEMBERS)){
            return message.reply({
                embeds:[
                    new MessageEmbed()
                    .setDescription(`Bu komudu kullanabilmek için: \`Kullanıcıları Yasakla\` yetkisine sahip olmalısın!`)
                ]
            }).then(x => setTimeout(() => x.delete(), 15000));
        }
        let member = message.mentions.users.first() || message.guild.members.cache.get(params[0]);
        let reason = params[1].slice(" ")
        if(!member)
        {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                    .setDescription(`Lütfen geçerli bir kullanıcı belirtin!`)
                ]
            }).then(x => setTimeout(() => x.delete(), 15000));
        }else{
            if(!reason){ reason: "Belirtilmedi"; }
            message.guild.members.ban(member.id, { reason: reason});
            message.reply({
                embeds:[
                    new MessageEmbed()
                    .setDescription(`${member} adlı kişiyi ${reason} adlı sebepten dolayı sunucudan uzaklaştırdım!`)
                ]
            })
        }
    }
}