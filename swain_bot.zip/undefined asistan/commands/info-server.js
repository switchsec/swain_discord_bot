let { Client, Message, MessageEmbed } = require("discord.js");
let moment = require("moment");
moment.locale("tr");

module.exports = {
    name: "info-guild",
    aliases: [
        "sunucu-bilgi",
        "sb",
        "sunucubilgi"
    ],
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String || Map || Number} params 
     */
    load: async function(client, message, params){
        let tiers = {
            NONE: "0",
            TIER_1: "1",
            TIER_2: "2",
            TIER_3: "3"
        }
        return message.reply({
            embeds: [
                new MessageEmbed()
                .setAuthor(`${message.guild.name} sunucusunun bilgileri:`, message.guild.iconURL())
                .setColor(`RANDOM`)
                .setThumbnail(message.guild.iconURL())
                .setDescription(`
                \`Genel bilgiler\`
                > Sunucu ismi: **${message.guild.name}**
                > Sunucu ID: **${message.guild.id}**
                > Sunucu sahibi: **<@${message.guild.ownerId}>**
                > Kurulum tarihi: **${moment(message.guild.createdAt).format("LLL")}**
                > Takviye seviyesi: **${tiers[message.guild.premiumTier]}**
                > Takviye sayısı: **${message.guild.premiumSubscriptionCount}**
                \`Üye istatistikleri\`
                > Üye sayısı: **${message.guild.memberCount}**
                > Bot sayısı: **${message.guild.members.cache.filter(z => z.user.bot).size}**
                \`Kanal istatistikleri\`
                > Sesli kanal sayısı: **${message.guild.channels.cache.filter(z => z.type === "GUILD_VOICE").size}**
                > Metin kanal sayısı: **${message.guild.channels.cache.filter(a => a.type === "GUILD_TEXT").size}**
                > Kategori sayısı: **${message.guild.channels.cache.filter(p => p.type === "GUILD_CATEGORY").size}**
                \`Emoji bilgileri\`
                > Emoji sayısı: **${message.guild.emojis.cache.size}**
                > Emojiler:
                > ${message.guild.emojis.cache.map(p => `${p}`)}
                \`Rol bilgileri\`
                > Rol sayısı: **${message.guild.roles.cache.size}**
                > Roller:
                > ${message.guild.roles.cache.map(z => `${z}`)}
                `)
                .setFooter(`${message.guild.name}`, message.guild.iconURL())
            ]
        })
    }
}