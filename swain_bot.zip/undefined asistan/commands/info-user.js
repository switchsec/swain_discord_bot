let { Client, Message, MessageEmbed } = require("discord.js");
let moment = require("moment");
moment.locale("tr");

module.exports = {
    name: "info-user",
    aliases: [
        "kullanıcı-bilgi",
        "kb",
        "kullanıcıbilgi"
    ],
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String || Map || Number} params 
     */
    load: async function(client, message, params){
        let presenceStatus = {
            online: "Çevrimiçi",
            dnd: "Rahatsız etmeyin",
            idle: "Boşta",
            invisible: "Görünmezde",
            offline: "Çevrimdışı"
        }
        let member = message.mentions.users.first() || message.guild.members.cache.get(params[0]);
        if(!member)
        {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                    .setDescription(`Lütfen geçerli bir kullanıcı belirtin!`)
                ]
            }).then(x => setTimeout(() => x.delete(), 15000));
        }else{
            let user = message.guild.members.cache.get(member.id);
            return message.reply({
                embeds: [
                    new MessageEmbed()
                    .setAuthor(`${user.displayName} adlı kullanıcının bilgileri: `, user.avatarURL({ dynamic:true }))
                    .setColor(`RANDOM`)
                    .setThumbnail(user.avatarURL({ dynamic:true }))
                    .setDescription(`
                    > Kullanıcı ismi **${member.user.tag}**
                    > Kullanıcı ID: **${user.id}**

                    > Kullanıcının rolleri: 
                    > ${user.roles.cache.map(r => `${r}`)}

                    > Hesap katılım tarihi: **${moment(user.joinedAt).format("LLL")}**
                    > Hesap kurulum tarihi: **${moment(user.createdAt).format("LLL")}**
                    `)
                    .setFooter(`${user.nickname}`, user.avatarURL({ dynamic:true }))
                ]
            })
        }
    }
}