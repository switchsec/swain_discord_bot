let { Client, Message, MessageEmbed, Permissions } = require("discord.js");
let moment = require("moment");
moment.locale("tr");

module.exports = {
    name: "ban-user",
    aliases: [
        "ban",
        "kick",
        "banuser",
        "banla"
    ],
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String || Map || Number} params 
     */
    load: async function(client, message, params){
        if(!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)){
            return message.reply({
                embeds:[
                    new MessageEmbed()
                    .setDescription(`Bu komudu kullanabilmek için: \`Sunucuyu Yönet\` yetkisine sahip olmalısın!`)
                ]
            }).then(x => setTimeout(() => x.delete(), 15000));
        }
        let role = message.mentions.roles.first();
        let channel = message.mentions.channels.first();
        if(!role)
        {
            return message.reply({
                embeds:[
                    new MessageEmbed()
                    .setDescription(`Lütfen bir rol belirt!`)
                ]
            }).then(msg => setTimeout(() => msg.delete(), 15000));
        }
        if(!channel)
        {
            return message.reply({
                embeds:[
                    new MessageEmbed()
                    .setDescription(`Log kanalını belirt!`)
                ]
            }).then(msg => setTimeout(() => msg.delete(), 15000));

        }
    }
}