module.exports = {
    token: "ODk4OTY1OTA3MDY0MzczMjc4.YWr5Pg.MSca4X5PdjYotMWDiRsXKn6jXLo",
    prefixes: [
        "?",
        "!"
    ],
    adminIDs: ["865885693569531905"],
    founderID: "865885693569531905"
}