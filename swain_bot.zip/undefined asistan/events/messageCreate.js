let { Client, Message } = require("discord.js");
let client = global.client;
let { prefixes } = require("../settings/Bot.Config");
module.exports = {
    name: "messageCreate",
    /**
     * 
     * @param {Message} message 
     */
    load: async function(message){
        if(!message || !message.guild || !message.channel) return;
        if(message.author.bot) return;
        let prefix = prefixes.find(p => message.content.toLowerCase().includes(p));
        if(!message.content.startsWith(prefix));
        var args = message.content.substring(prefixes.some(x => x.length)).split(" ");
        var command = args[0];
        params = args.splice(1);
        let cmd = global.commands.get(command) || global.aliases.get(command);
        /*if(!cmd)
        {
            return message.reply(`Aradığın komudu bulamadım!`).then(x => setTimeout(() => x.delete(), 15000));
        }*/
        if(cmd)
        {
            cmd.load(client, message, params);
        }
    }
}