let client = global.client;
let { Client } = require("discord.js");
module.exports = {
    name: "ready",
    /**
     * 
     * @param {Client} client 
     */
    load: async function(client){
        console.log("Bot ready!");
    }
}