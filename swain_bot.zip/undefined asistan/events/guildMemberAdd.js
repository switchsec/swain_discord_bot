let { Client, Member } = require("discord.js");
let client = global.client;
let { prefixes } = require("../settings/Bot.Config");
module.exports = {
    name: "guildMemberAdd",
    /**
     * 
     * @param {Member} member 
     */
    load: async function(member){

    }
}