let { Client } = require("discord.js");
let clientOptions = require("./base/Client.Options");
let botConfig = require("./settings/Bot.Config");
let { codes } = require("./base/Bot.Options");
let Handler = require("./base/Handler.Structures");

const client = new Client({
    intents: clientOptions.intents,
    partials: clientOptions.partials,
    allowedMentions: clientOptions.allowedMentions,
    presence: clientOptions.presence
});
let commands = global.commands = new Map();
let aliases = global.aliases = new Map();
global.client = client;

Handler.init("./commands", commands, aliases);
Handler.event("./events", client);

client.login(botConfig.token).catch(err => console.error(`Error $!#${codes.api}`));