module.exports = {
    database:{
        mongoURL: "",
        lowPath: "db.json"
    },
    system: {
        music: false,
        guard: false,
        moderation: false,
        asistan: false,
        stat: false,
        dm: false
    },
    codes: {
        api: 5,
        connection: 10
    }
}