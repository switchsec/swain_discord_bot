let fs = require("fs");
let Discord = require("discord.js");
class Handler {
    /**
     * 
     * @param {String} folder 
     * @param {Map} commands 
     * @param {Map} aliases 
     */
    static async init(folder, commands, aliases)
    {
        fs.readdir(folder, async(err, files) => {
            if(err) throw new ErrorEvent(err);
            files.filter(file => file.endsWith(".js")).forEach(async function(prop) {
                if(!prop) throw new Error(err);
                let req = require(`../${folder}/${prop}`);
                commands.set(req.name, req);
                req.aliases.forEach(async function (alias) {
                    aliases.set(alias, req);
                });
                console.log(`${prop} yüklendi.`);
            });
        });
    }
    /**
     * 
     * @param {String} folder 
     * @param {Discord.Client} client 
     */
    static async event(folder, client)
    {
        fs.readdir(folder, async(err, files) => {
            if(err) throw new ErrorEvent(err);
            files.filter(file => file.endsWith(".js")).forEach(async function(prop) {
                if(!prop) throw new Error(err);
                let req = require(`../${folder}/${prop}`);
                client.on(req.name, req.load);
                console.log(`${prop} yüklendi.`);
            });
        })
    }
}
module.exports = Handler;